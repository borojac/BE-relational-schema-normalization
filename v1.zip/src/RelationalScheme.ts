export class RelationalScheme {
    attributes: string[]

    constructor(attributes: string[] = []) {
        if (!Array.isArray(attributes)) {
            throw new Error('Relational scheme attributes must be array of strings');
        }
        this.attributes = attributes;
    }
}