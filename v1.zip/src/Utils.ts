import { FunctionalDependency } from "./FunctionalDependency";
import { FunctionalDependencySet } from "./FunctionalDependencySet";

export class Utils {
    public static closureOfSetOfFunctionalDependenciesUsingAttributesClosure(fdsParam: FunctionalDependencySet) {
        const relationalScheme: Set<string> = Utils.extractRelationalSchemaAttributes(fdsParam);
        const attributeSubsets: Set<string>[] = Utils.generateSubsets(relationalScheme);

        const fds: FunctionalDependencySet = new FunctionalDependencySet();
        for (let attributeSubset of attributeSubsets) {
            const alphaPlus = Utils.closureOfSetOfAttributes(attributeSubset, fdsParam);
            for (let alphaPlusSubset of Utils.generateSubsets(alphaPlus)) {
                fds.add(new FunctionalDependency(attributeSubset, alphaPlusSubset));
            }
        }
        return fds;
    }

    public static closureOfSetOfFunctionalDependencies(fdsParam: FunctionalDependencySet) {
        const fPlus = new FunctionalDependencySet(fdsParam);

        // Reflexivity
        const relationalSchemeSubsets: Set<string>[] = Utils.generateSubsets(
            Utils.extractRelationalSchemaAttributes(fdsParam)
        );
        for (const relationalSchemeSubset of relationalSchemeSubsets) {
            const alphaSubsets: Set<string>[] = Utils.generateSubsets(relationalSchemeSubset);
            for (const alphaSubset of alphaSubsets) {
                fPlus.add(new FunctionalDependency(relationalSchemeSubset, alphaSubset));
            }
        }

        let fPlusPrev: FunctionalDependencySet;
        do {
            fPlusPrev = new FunctionalDependencySet(fPlus);

            // Augmentation
            const fdsLen = fPlus.size();
            for (let i = 0; i < fdsLen; i++) {
                const fd = fPlus.fdArray[i];
                relationalSchemeSubsets.forEach(
                    augmentationSubset => fPlus.add(
                        new FunctionalDependency(Utils.union(fd.determinant, augmentationSubset),
                            Utils.union(fd.dependent, augmentationSubset))
                    )
                );
            }

            // Transitivity
            for (let i = 0; i < fPlus.fdArray.length - 1; i++) {
                for (let j = i + 1; j < fPlus.fdArray.length; j++) {
                    if (i != j) {
                        const fd1 = fPlus.fdArray[i];
                        const fd2 = fPlus.fdArray[j];
                        if (Utils.areSetOfAttributesEqual(fd1.dependent, fd2.determinant)) {
                            fPlus.add(new FunctionalDependency(fd1.determinant, fd2.dependent));
                        }
                        if (Utils.areSetOfAttributesEqual(fd2.dependent, fd1.determinant)) {
                            fPlus.add(new FunctionalDependency(fd2.determinant, fd1.dependent));
                        }
                    }
                }
            }
        } while (!fPlus.equals(fPlusPrev))

        return fPlus;
    }

    public static closureOfSetOfAttributes(alpha: Set<string>, fds: FunctionalDependencySet): Set<string> {
        let alphaPlus: Set<string> = new Set<string>(alpha);
        let aplhaPlusPrev: Set<string>;
        do {
            aplhaPlusPrev = new Set<string>(alphaPlus);
            for (let fd of fds.fdArray) {
                if (Utils.isSubsetOf(fd.determinant, alphaPlus)) {
                    alphaPlus = Utils.union(alphaPlus, fd.dependent);
                }
            }
        } while (!Utils.areSetOfAttributesEqual(aplhaPlusPrev, alphaPlus))
        return alphaPlus;
    }

    public static computeMinimalCover(fds: FunctionalDependencySet): FunctionalDependencySet {
        let fm: FunctionalDependencySet = new FunctionalDependencySet(fds);

        fm = Utils.decomposeFunctionalDependencies(fm);

        for (let fd of new FunctionalDependencySet(fds).fdArray) {
            if (fd.dependent.size === 1 && fd.determinant.size > 1) {
                fm = Utils.removeExtraneousAttributes(fd, fm);
            }
        }

        for (let fd of fm.fdArray) {
            if (fd.dependent.size === 1) {
                const dependent: string = fd.dependent.values().next().value;
                const alphaPlus: Set<string> = Utils.closureOfSetOfAttributes(fd.determinant, fm.remove(fd));
                if (alphaPlus.has(dependent)) {
                    fm = fm.remove(fd);
                }
            }
        }

        return fm;
    }

    public static removeExtraneousAttributes(fdParam: FunctionalDependency, fdsParam: FunctionalDependencySet): FunctionalDependencySet {
        let fd = new FunctionalDependency(fdParam.determinant, fdParam.dependent);
        let fds: FunctionalDependencySet = new FunctionalDependencySet(fdsParam);
        for (let attribute of new Set<string>(fdParam.determinant)) {
            if (fd.determinant.size > 1) {
                let newFd = new FunctionalDependency(new Set([...fd.determinant].filter(attr => attr != attribute)), fd.dependent);

                const alphaPlus = Utils.closureOfSetOfAttributes(newFd.determinant, fdsParam);
                if (Utils.isSubsetOf(fd.dependent, alphaPlus, false)) {
                    fds = fds.replace(fd, newFd);
                    fd = new FunctionalDependency(newFd.determinant, newFd.dependent);
                }
            }
        }
        return fds;
    }

    public static decomposeFunctionalDependencies(fds: FunctionalDependencySet): FunctionalDependencySet {
        let newFds: FunctionalDependencySet = new FunctionalDependencySet();
        for (let fd of fds.fdArray) {
            const decomposedFdArray: FunctionalDependency[] = fd.decompose();
            for (let decomposedFd of decomposedFdArray) {
                newFds.add(decomposedFd);
            }
        }

        return newFds;
    }

    public static areSetOfAttributesEqual(s1: Set<string>, s2: Set<string>) {
        return s1.size === s2.size && [...s1].every((el) => s2.has(el));
    }

    public static isSubsetOf(a: Set<string>, b: Set<string>, isStrictSubset: boolean = false) {
        const isSubset = [...a].every(el => b.has(el));

        if (!isSubset || (isStrictSubset && a.size === b.size)) return false;

        return true;
    }

    public static union(a: Set<string>, b: Set<string>) {
        return new Set([...a, ...b]);
    }

    public static generateSubsets(set: Set<string>): Set<string>[] {
        const subsets: Set<string>[] = [];

        for (const element of set) {
            const currentLength = subsets.length;
            subsets.push(new Set([element]));
            for (let i = 0; i < currentLength; i++) {
                const newSubset = new Set(subsets[i]);
                newSubset.add(element);
                subsets.push(newSubset);
            }
        }

        return subsets;
    }

    public static extractRelationalSchemaAttributes(fds: FunctionalDependencySet): Set<string> {
        let res: Set<string> = new Set<string>();
        for (let fd of fds.fdArray) {
            res = new Set([...res, ...fd.determinant, ...fd.dependent]);
        }
        return res;
    }
}