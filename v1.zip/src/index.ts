import { FunctionalDependency } from "./FunctionalDependency";
import { FunctionalDependencySet } from "./FunctionalDependencySet";
import { Utils } from "./Utils";

const fds = new FunctionalDependencySet([
    new FunctionalDependency(new Set(['A', 'B']), new Set(['C'])),
    new FunctionalDependency(new Set(['B']), new Set(['A', 'D'])),
    new FunctionalDependency(new Set(['C']), new Set(['B'])),
    new FunctionalDependency(new Set(['B','C','D']), new Set(['A'])),
])

const res = Utils.computeMinimalCover(fds);
console.log(res.fdArray)