import { Utils } from "../src/Utils";

describe('Utils functionality', () => {
    describe('Generating subsets', () => {
        it('generated subsets are correct', () => {
            // console.log(Utils.generateSubsets(new Set(['A', 'B', 'C'])))
            // TO-DO
        });
    })
})