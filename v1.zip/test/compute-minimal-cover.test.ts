import { FunctionalDependency } from "../src/FunctionalDependency";
import { FunctionalDependencySet } from "../src/FunctionalDependencySet";
import { Utils } from "../src/Utils";

describe('Compute minimal cover', () => {
    it('should compute correct minimal cover (1)', () => {
        const fds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['A', 'B']), new Set(['C'])),
            new FunctionalDependency(new Set(['B']), new Set(['A', 'D'])),
            new FunctionalDependency(new Set(['C']), new Set(['B'])),
            new FunctionalDependency(new Set(['B','C','D']), new Set(['A'])),
        ])
        
        const minimalCoverFds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['B']), new Set(['A'])),
            new FunctionalDependency(new Set(['B']), new Set(['C'])),
            new FunctionalDependency(new Set(['B']), new Set(['D'])),
            new FunctionalDependency(new Set(['C']), new Set(['B'])),
        ])

        const res = Utils.computeMinimalCover(fds);

        expect(res.fdArray.length).toEqual(minimalCoverFds.fdArray.length);
        expect(Utils.closureOfSetOfFunctionalDependencies(res).equals(Utils.closureOfSetOfFunctionalDependencies(minimalCoverFds))).toBeTruthy();
    });

    it('should compute correct minimal cover (2)', () => {
        const fds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['A']), new Set(['B'])),
            new FunctionalDependency(new Set(['A', 'B']), new Set(['C'])),
            new FunctionalDependency(new Set(['D']), new Set(['A', 'C'])),
            new FunctionalDependency(new Set(['D']), new Set(['E'])),
        ])
        
        const minimalCoverFds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['A']), new Set(['B'])),
            new FunctionalDependency(new Set(['A']), new Set(['C'])),
            new FunctionalDependency(new Set(['D']), new Set(['A'])),
            new FunctionalDependency(new Set(['D']), new Set(['E'])),
        ])

        const res = Utils.computeMinimalCover(fds);

        expect(res.fdArray.length).toEqual(minimalCoverFds.fdArray.length);
        expect(Utils.closureOfSetOfFunctionalDependencies(res).equals(Utils.closureOfSetOfFunctionalDependencies(minimalCoverFds))).toBeTruthy();
    });

    it('should compute correct minimal cover (3)', () => {
        const fds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['B']), new Set(['A'])),
            new FunctionalDependency(new Set(['D']), new Set(['A'])),
            new FunctionalDependency(new Set(['A', 'B']), new Set(['D'])),
        ])
        
        const minimalCoverFds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['B']), new Set(['D'])),
            new FunctionalDependency(new Set(['D']), new Set(['A'])),
        ])

        const res = Utils.computeMinimalCover(fds);

        expect(res.fdArray.length).toEqual(minimalCoverFds.fdArray.length);
        expect(Utils.closureOfSetOfFunctionalDependencies(res).equals(Utils.closureOfSetOfFunctionalDependencies(minimalCoverFds))).toBeTruthy();
    });

    it('should compute correct minimal cover (4)', () => {
        const fds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['a']), new Set(['b'])),
            new FunctionalDependency(new Set(['a', 'c']), new Set(['d'])),
            new FunctionalDependency(new Set(['a', 'c']), new Set(['e'])),
            new FunctionalDependency(new Set(['a','d']), new Set(['e'])),
            new FunctionalDependency(new Set(['a','d']), new Set(['c'])),
            new FunctionalDependency(new Set(['c','d']), new Set(['a'])),
            new FunctionalDependency(new Set(['c','d']), new Set(['b'])),
            new FunctionalDependency(new Set(['c','d']), new Set(['e'])),
        ])
        
        const minimalCoverFds = new FunctionalDependencySet([
            new FunctionalDependency(new Set(['a']), new Set(['b'])),
            new FunctionalDependency(new Set(['c', 'd']), new Set(['e'])),
            new FunctionalDependency(new Set(['c', 'd']), new Set(['a'])),
            new FunctionalDependency(new Set(['a', 'd']), new Set(['c'])),
            new FunctionalDependency(new Set(['a', 'c']), new Set(['d'])),
        ])

        const res = Utils.computeMinimalCover(fds);

        expect(res.fdArray.length).toEqual(minimalCoverFds.fdArray.length);
        expect(Utils.closureOfSetOfFunctionalDependencies(res).equals(Utils.closureOfSetOfFunctionalDependencies(minimalCoverFds))).toBeTruthy();
    });
});